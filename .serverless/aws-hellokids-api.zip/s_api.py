import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='bopool',
    application_name='aws-hellokids-api',
    app_uid='sD154y0bpnh8NfvlHw',
    org_uid='8f616ade-84ee-446e-a779-9ebf2e55345e',
    deployment_uid='04879a2b-8b70-404e-9a1d-f055ac1ac61a',
    service_name='aws-hellokids-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-hellokids-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
